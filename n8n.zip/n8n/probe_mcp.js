const { spawn } = require('child_process');

// The command provided by the user
const args = [
    '-y',
    'supergateway',
    '--streamableHttp',
    'https://n8n.smartnvr.shop/mcp-server/http',
    '--header',
    'authorization:Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJjMTdmNGZlNC1kMzE4LTRiMWEtYmQ2OC0wYmMxYjc5YmFiOGUiLCJpc3MiOiJuOG4iLCJhdWQiOiJtY3Atc2VydmVyLWFwaSIsImp0aSI6ImZhNDI3OGEwLWJjNWYtNDRlYS1hYmVhLTRkODY5OTA5ZDVkMSIsImlhdCI6MTc2NzQzMDU5NX0.E9HKKIqndVA9Yk4yfG2eiOaRlD1tyPkqPQWcVnykGa4'
];

console.log("Spawning supergateway...");
const cp = spawn('npx', args, { stdio: ['pipe', 'pipe', 'pipe'] });

let buffer = '';

cp.stdout.on('data', (data) => {
    const chunk = data.toString();
    console.log(`[STDOUT chunk]: ${chunk}`);
    buffer += chunk;

    // Check if we have a complete message (simple heuristic for JSON-RPC)
    const lines = buffer.split('\n');
    for (const line of lines) {
        if (!line.trim()) continue;
        try {
            const msg = JSON.parse(line);
            console.log("Received JSON:", msg);

            // If we receive the capabilities/init response, ask for tools
            if (msg.result && msg.id === 1) {
                console.log("Initialization successful. Requesting tools...");
                const toolsReq = {
                    jsonrpc: "2.0",
                    method: "tools/list",
                    id: 2
                };
                cp.stdin.write(JSON.stringify(toolsReq) + "\n");
            }
            // If we receive the tool list
            if (msg.result && msg.id === 2) {
                console.log("TOOLS RECEIVED:");
                if (msg.result.tools) {
                    msg.result.tools.forEach(t => {
                        console.log(`Tool: ${t.name}`);
                        console.log(`Description: ${t.description}`);
                        console.log(`Schema: ${JSON.stringify(t.inputSchema)}`);
                        console.log('---');
                    });
                } else {
                    console.log("No tools found in result:", msg.result);
                }
                process.exit(0);
            }
        } catch (e) {
            // Partial line or not JSON
        }
    }
});

cp.stderr.on('data', (data) => {
    console.error(`[STDERR]: ${data.toString()}`);
});

cp.on('close', (code) => {
    console.log(`Child process exited with code ${code}`);
});

// Send Initialize Request immediately
// JSON-RPC 2.0 as per MCP spec requires an 'initialize' handshake first? 
// Supergateway might just proxy. Let's try raw JSON-RPC tools/list first, 
// but standard MCP requires initialize.
const initReq = {
    jsonrpc: "2.0",
    method: "initialize",
    params: {
        protocolVersion: "2024-11-05",
        capabilities: {},
        clientInfo: {
            name: "antigravity-probe",
            version: "1.0"
        }
    },
    id: 1
};

// Wait a tiny bit for process cold start then send
setTimeout(() => {
    console.log("Sending Initialize...");
    cp.stdin.write(JSON.stringify(initReq) + "\n");
}, 2000);

// Timeout
setTimeout(() => {
    console.log("Timeout reached. Exiting.");
    process.exit(1);
}, 30000);
