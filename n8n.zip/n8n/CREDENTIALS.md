# n8n Database Credentials

These are the credentials for the local PostgreSQL database integrated with n8n.

## 1. For n8n Workflows (Internal)
Use these settings inside the **Postgres Chat Memory** or **Postgres Vector Store** nodes within n8n.

| Parameter | Value |
| :--- | :--- |
| **Host** | `postgres` |
| **Port** | `5432` |
| **Database** | `n8n` |
| **User** | `n8n` |
| **Password** | `n8n_password` |

> **Imporant**: Do NOT use `localhost` or port `57843` inside n8n nodes.

## 2. From Your Computer (External)
Use these settings for tools like DBeaver, TablePlus, or local scripts.

| Parameter | Value |
| :--- | :--- |
| **Host** | `localhost` |
| **Port** | `57843` |
| **Database** | `n8n` |
| **User** | `n8n` |
| **Password** | `n8n_password` |
