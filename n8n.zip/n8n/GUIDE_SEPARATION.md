# Separation Strategy: Chat Memory & Vector Storage

To ensure that **Chat Memory** and **Vector Storage** are automatically separated by workflow, use the following configuration in your n8n nodes.

## 1. Chat Memory (Postgres)

When using the **Postgres Chat Memory** node (or similar):

- **Table Name**: Defaults to `n8n_chat_histories`. Ensure this is set correctly in your node.
- **Session ID**: Set this to `{{ $workflow.name }}` or `{{ $workflow.id }}`.
  
  This ensures that the conversation history is tied specifically to the running workflow's identity.

  > **Tip**: If you want unique sessions *per user* within a workflow, use a combination like `{{ $workflow.name }}-{{ $json.userId }}`.

## 2. Vector Store (Postgres / pgvector)

When using **Postgres Vector Store** nodes for RAG (Retrieval Augmented Generation):

### Ingestion (Insert)
- **Metadata**: Add a metadata field key named `workflow_id` (or `workflow_name`) and set its value to `{{ $workflow.name }}`.

### Retrieval (Search)
- **Metadata Filter**: Configure the filter to only retrieve documents where `workflow_id` matches the current workflow.
  - **Key**: `workflow_id`
  - **Value**: `{{ $workflow.name }}`
  - **Operator**: `Equal`

---

## 3. Why this works
By tagging both memory sessions and vector embeddings with the `$workflow.name` (or ID), you create logical partitions within the same database tables. This prevents Workflow A from accessing Workflow B's context or knowledge base.
