const { spawn } = require('child_process');

const toolName = process.argv[2];
const toolArgs = process.argv[3] ? JSON.parse(process.argv[3]) : {};

if (!toolName) {
    console.error("Usage: node call_mcp.js <tool_name> <json_args>");
    process.exit(1);
}

// The command provided by the user
const args = [
    '-y',
    'supergateway',
    '--streamableHttp',
    'https://n8n.smartnvr.shop/mcp-server/http',
    '--header',
    'authorization:Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJjMTdmNGZlNC1kMzE4LTRiMWEtYmQ2OC0wYmMxYjc5YmFiOGUiLCJpc3MiOiJuOG4iLCJhdWQiOiJtY3Atc2VydmVyLWFwaSIsImp0aSI6ImZhNDI3OGEwLWJjNWYtNDRlYS1hYmVhLTRkODY5OTA5ZDVkMSIsImlhdCI6MTc2NzQzMDU5NX0.E9HKKIqndVA9Yk4yfG2eiOaRlD1tyPkqPQWcVnykGa4'
];

// console.log(`calling tool ${toolName}...`);

const cp = spawn('npx', args, { stdio: ['pipe', 'pipe', 'pipe'] });

let buffer = '';
let initialized = false;

cp.stdout.on('data', (data) => {
    const chunk = data.toString();
    buffer += chunk;

    const lines = buffer.split('\n');
    // iterate all except last (which might be partial)
    while (lines.length > 1) {
        const line = lines.shift();
        if (!line.trim()) continue;
        try {
            const msg = JSON.parse(line);

            // Initialization Response
            if (msg.result && msg.id === 1) {
                initialized = true;
                // Call Tool
                const callReq = {
                    jsonrpc: "2.0",
                    method: "tools/call",
                    params: {
                        name: toolName,
                        arguments: toolArgs
                    },
                    id: 2
                };
                cp.stdin.write(JSON.stringify(callReq) + "\n");
            }

            // Tool Response
            if (msg.id === 2) {
                if (msg.error) {
                    console.error("Tool Error:", JSON.stringify(msg.error, null, 2));
                } else {
                    console.log(JSON.stringify(msg.result, null, 2));
                }
                process.exit(0);
            }

        } catch (e) {
            // ignore
        }
    }
    buffer = lines[0]; // keep remainder
});

cp.stderr.on('data', (data) => {
    // console.error(`[STDERR]: ${data.toString()}`);
});

// Initialize
const initReq = {
    jsonrpc: "2.0",
    method: "initialize",
    params: {
        protocolVersion: "2024-11-05",
        capabilities: {},
        clientInfo: { name: "antigravity-caller", version: "1.0" }
    },
    id: 1
};

// Wait for spawn
setTimeout(() => {
    cp.stdin.write(JSON.stringify(initReq) + "\n");
}, 2000);

setTimeout(() => {
    console.error("Timeout reached.");
    process.exit(1);
}, 30000);
