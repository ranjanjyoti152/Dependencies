-- Enable pgvector extension
CREATE EXTENSION IF NOT EXISTS vector;

-- Create a default table for chat messages if it doesn't exist
-- This schema is compatible with n8n's default Postgres Chat Memory node
CREATE TABLE IF NOT EXISTS chat_messages (
    id SERIAL PRIMARY KEY,
    session_id TEXT NOT NULL,
    message JSONB NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_chat_messages_session_id ON chat_messages(session_id);
