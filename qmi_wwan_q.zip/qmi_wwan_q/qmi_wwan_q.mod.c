#include <linux/module.h>
#define INCLUDE_VERMAGIC
#include <linux/build-salt.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

BUILD_SALT;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif

static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0x8044d9a7, "module_layout" },
	{ 0xd5a41789, "param_ops_uint" },
	{ 0xfcd0fc34, "param_ops_long" },
	{ 0x86058a6b, "ethtool_op_get_link" },
	{ 0xa5929e5b, "usbnet_tx_timeout" },
	{ 0x2aff1435, "usbnet_change_mtu" },
	{ 0x2e61d6b3, "eth_validate_addr" },
	{ 0xbad513a2, "usbnet_stop" },
	{ 0x24a3816e, "usb_deregister" },
	{ 0x6237878, "usb_register_driver" },
	{ 0xcbd4898c, "fortify_panic" },
	{ 0x6cbbfc54, "__arch_copy_to_user" },
	{ 0xa916b694, "strnlen" },
	{ 0x3c3fce39, "__local_bh_enable_ip" },
	{ 0xa1f5d9a1, "netif_schedule_queue" },
	{ 0xb5b54b34, "_raw_spin_unlock" },
	{ 0x7a2af7b4, "cpu_number" },
	{ 0xba8fbd64, "_raw_spin_lock" },
	{ 0x35b2494c, "usb_autopm_put_interface" },
	{ 0xa85b2d1, "usb_autopm_get_interface" },
	{ 0x3c5d543a, "hrtimer_start_range_ns" },
	{ 0x40286533, "__alloc_skb" },
	{ 0x365acda7, "set_normalized_timespec64" },
	{ 0x6ac91680, "softnet_data" },
	{ 0x138a4d00, "usbnet_start_xmit" },
	{ 0x37a0cba, "kfree" },
	{ 0xdeb2163d, "usbnet_disconnect" },
	{ 0xea3c74e, "tasklet_kill" },
	{ 0x93f1d74c, "unregister_netdev" },
	{ 0xc9ec4e21, "free_percpu" },
	{ 0x2ce93caf, "netdev_rx_handler_unregister" },
	{ 0x9d008684, "kfree_skb" },
	{ 0x3c12dfe, "cancel_work_sync" },
	{ 0x46a4b118, "hrtimer_cancel" },
	{ 0x4b0a3f52, "gic_nonsecure_priorities" },
	{ 0x12a4e128, "__arch_copy_from_user" },
	{ 0xaebd1b18, "cpu_hwcaps" },
	{ 0x69c684c5, "consume_skb" },
	{ 0xdb72a830, "netif_receive_skb" },
	{ 0x9d2ab8ac, "__tasklet_schedule" },
	{ 0x4c98d79b, "cpu_hwcap_keys" },
	{ 0x14b89635, "arm64_const_caps_ready" },
	{ 0x2364c85a, "tasklet_init" },
	{ 0xf8f45406, "usbnet_probe" },
	{ 0xe44eb81e, "dev_queue_xmit" },
	{ 0xd35cce70, "_raw_spin_unlock_irqrestore" },
	{ 0x34db050b, "_raw_spin_lock_irqsave" },
	{ 0x75bc44e5, "netif_rx_ni" },
	{ 0x349cba85, "strchr" },
	{ 0x4bbf8be6, "arp_create" },
	{ 0xc5850110, "printk" },
	{ 0x77a23c50, "usbnet_skb_return" },
	{ 0xfac00a9b, "__netdev_alloc_skb" },
	{ 0xfee38154, "skb_pull" },
	{ 0x86c6ddaf, "skb_put" },
	{ 0x949fa222, "ether_setup" },
	{ 0xc5b6f236, "queue_work_on" },
	{ 0x2d3385d3, "system_wq" },
	{ 0x6e720ff2, "rtnl_unlock" },
	{ 0xa3244125, "netdev_rx_handler_register" },
	{ 0xc7a4fbed, "rtnl_lock" },
	{ 0x5d82b5b0, "netdev_info" },
	{ 0x454b6d98, "netdev_err" },
	{ 0x620c85ae, "free_netdev" },
	{ 0xe914e41e, "strcpy" },
	{ 0xe77dbee8, "netif_device_attach" },
	{ 0x30cba6b2, "register_netdev" },
	{ 0xaf793668, "__alloc_percpu_gfp" },
	{ 0x5e515be6, "ktime_get_ts64" },
	{ 0x2d0684a9, "hrtimer_init" },
	{ 0x88dcf3d4, "alloc_netdev_mqs" },
	{ 0x3c3ff9fd, "sprintf" },
	{ 0x8e031cc9, "usbnet_resume" },
	{ 0xaa3f4686, "usbnet_suspend" },
	{ 0xdcb764ad, "memset" },
	{ 0x86332725, "__stack_chk_fail" },
	{ 0x9e854408, "usb_string" },
	{ 0xce283e35, "kmem_cache_alloc_trace" },
	{ 0x2c76de84, "kmalloc_caches" },
	{ 0x41ed3709, "get_random_bytes" },
	{ 0xa03cecda, "_dev_err" },
	{ 0x4829a47e, "memcpy" },
	{ 0xe8b21af, "usb_cdc_wdm_register" },
	{ 0x4198fd9c, "usbnet_get_endpoints" },
	{ 0x166c206f, "usbnet_open" },
	{ 0xd66a9593, "eth_commit_mac_addr_change" },
	{ 0xaec260de, "eth_prepare_mac_addr_change" },
	{ 0xd2f5c6b0, "usbnet_get_drvinfo" },
	{ 0x656e4a6e, "snprintf" },
	{ 0xc488f321, "netif_tx_wake_queue" },
	{ 0x3706f65b, "netif_carrier_on" },
	{ 0xb9ee188d, "netif_carrier_off" },
	{ 0x3feea40, "cpumask_next" },
	{ 0x3928efe9, "__per_cpu_offset" },
	{ 0x17de3d5, "nr_cpu_ids" },
	{ 0xa5f7cf37, "__cpu_possible_mask" },
	{ 0xad995dac, "netdev_stats_to_stats64" },
	{ 0x20000329, "simple_strtoul" },
	{ 0x6303f42d, "usb_control_msg" },
	{ 0xbd5b60f, "usb_driver_release_interface" },
	{ 0xa6f79389, "__dev_kfree_skb_any" },
	{ 0xce0b0ed1, "skb_push" },
	{ 0x795ee27e, "_dev_info" },
	{ 0x1fdc7df2, "_mcount" },
};

MODULE_INFO(depends, "cdc-wdm");

MODULE_ALIAS("usb:v05C6p9003d*dc*dsc*dp*ic*isc*ip*in04*");
MODULE_ALIAS("usb:v05C6p9215d*dc*dsc*dp*ic*isc*ip*in04*");
MODULE_ALIAS("usb:v2C7Cp0125d*dc*dsc*dp*ic*isc*ip*in04*");
MODULE_ALIAS("usb:v2C7Cp0121d*dc*dsc*dp*ic*isc*ip*in04*");
MODULE_ALIAS("usb:v2C7Cp0191d*dc*dsc*dp*ic*isc*ip*in04*");
MODULE_ALIAS("usb:v2C7Cp0195d*dc*dsc*dp*ic*isc*ip*in04*");
MODULE_ALIAS("usb:v2C7Cp0700d*dc*dsc*dp*ic*isc*ip*in03*");
MODULE_ALIAS("usb:v2C7Cp0306d*dc*dsc*dp*ic*isc*ip*in04*");
MODULE_ALIAS("usb:v2C7Cp030Bd*dc*dsc*dp*ic*isc*ip*in04*");
MODULE_ALIAS("usb:v2C7Cp0512d*dc*dsc*dp*ic*isc*ip*in04*");
MODULE_ALIAS("usb:v2C7Cp0296d*dc*dsc*dp*ic*isc*ip*in04*");
MODULE_ALIAS("usb:v2C7Cp0435d*dc*dsc*dp*ic*isc*ip*in04*");
MODULE_ALIAS("usb:v2C7Cp0620d*dc*dsc*dp*ic*isc*ip*in04*");
MODULE_ALIAS("usb:v2C7Cp0800d*dc*dsc*dp*ic*isc*ip*in04*");
MODULE_ALIAS("usb:v2C7Cp0801d*dc*dsc*dp*ic*isc*ip*in04*");

MODULE_INFO(srcversion, "4D1B3AC521E6C0557F76B39");
